# http://designtheory.org/database/t-designs/
tdesign_file = "t2-v73-b73-r9-k9-L1.icgsa.txt"
#~ tdesign_file = "t2-v31-b155-r20-k4-L2.icgs.txt" 
import re
with open('t-designs/'+tdesign_file, 'r') as tf:
    findings = re.findall('<blocks ordered="true">(.*?)</blocks>', tf.read(), re.DOTALL )
    print "block groups:", len(findings)
    blocks_txt = findings[0]
    #~ match = re.search('<blocks ordered="true">(.*?)</blocks>', tf.read(), re.DOTALL )
    #~ blocks_txt = match.group(1)


blocks_py = blocks_txt.replace("<block>", "[").\
                    replace("</block>", "], ").\
                    replace("<z>", "" ).\
                    replace("</z>", ", " )

cards = eval("["+blocks_py+"]")

with open("cards.json", 'w') as f:
    f.write("cards, images: %s %s\n" %  (len(cards), max(map(max, cards)) ) ) #(imgs4pairsN, imgs4singlejoins_count )  )
    f.write ( "\n".join( map(str, cards )) ) 

def frequencies_of_points(blocks):
    freqs = {}
    for block in blocks:
        for point in block:
            if point in freqs:
                freqs[point] += 1
            else:
                freqs[point] = 1
    from pprint import pprint
    pprint(freqs)
    return freqs

frequencies_of_points(cards)
